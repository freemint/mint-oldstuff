/* file:  shutdown.c
 *        shut down the system
 *
 * Based on Ulrich's Kuehn reboot.c.
 *
 * Draco, 31.V.1997.
 */

#include <mintbind.h>
#include <signal.h>
#include <stdio.h>
#include <time.h>
#include <utmp.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <syslog.h>

#define _PATH_NOLOGIN 	"/etc/nologin"
#define _PATH_FASTBOOT 	"/etc/fastboot"
#define _PATH_UTMP	"/etc/utmp"
#define _PATH_WALL	"/etc/shutdown.wall"

int t = 1;
char *shutn;
char common[]="\n*** The system is going down for ";
char reboot[]="reboot ";
char maintn[]="maintenance ";

void write_msg(char *ttyname, char *ttytext)
{
	char	ttypath[16];
	FILE	*tty;
	char	buf[1024];

	sprintf(ttypath, "/dev/%s", ttyname);
	if ((tty = fopen(ttypath, "w")))
	{
		fputs(ttytext, tty);
		fclose(tty);
	}

}
 
void dowall(int sleeptime, int rb)
{
	long tm;
	int fh;
	struct utmp ut;
	FILE *fd;
	char *reason, line[MAXLINE], message[MAXLINE + 10];

	if (rb)
		reason = reboot;
	else
		reason = maintn;

	if ((fh = open(_PATH_UTMP, O_RDONLY)) < 0)
	{
		fprintf(stderr, "error: can't find utmp file!\n");
		exit(-1);
	}
	else
	{
		while (read(fh, &ut, sizeof(struct utmp)) == sizeof(struct utmp))
		{
			if (*ut.ut_name)
			{
				tm = time(0);
				sprintf(line, "\n\n*** Broadcast message from operator, %s\n", ctime(&tm));
				write_msg(ut.ut_line, line);

				if ((fd = fopen(_PATH_WALL, "r")) != NULL)
				{
					while (fgets(line, sizeof(line), fd) != NULL)
					{
						sprintf(message, "*** %s", line);
						write_msg(ut.ut_line, message);
					}
					(void) fflush(stdout);
					(void) fclose(fd);
				}

				if (t == 1 || t == 0)
					sprintf(line, "%s%sNOW!\n\n", common, reason);
				else
				{
					if (t > 59)
						sprintf(line, "%s%sin %d minutes!\n\n", common, reason, t/60);
					else
						sprintf(line, "%s%sin %d seconds!\n\n", common, reason, t);
				}
				write_msg(ut.ut_line, line);
			}

		}
		close(fh);
	}
	sleep(sleeptime);	

}

void dohelp()
{
	printf("Usage:    %s [-krhfct] [secs]\n", shutn);
	printf("                  -k:      don't really shutdown, only warn.\n");
	printf("                  -r:      reboot after shutdown\n");
	printf("                  -h:      shutdown and quit to TOS\n");
	printf("                  -f:      do a 'fast' reboot\n");
	printf("                  -c:      cancel a running shutdown\n");
	printf("                  -t secs: delay between warning and kill signal\n");
	printf("          ** default action is immediate system halt. **\n");
}

int main(int argc, char *argv[])
{
	char *s;
	int k = 0, r = 0, h = 0, f = 0, c = 0;
	char *hostname;

	shutn = argv[0];

	if (geteuid() != 0)
	{
		printf("You must be root to shutdown the system.\n");
		return -1;
	}
	
	if ((hostname = getenv("HOST")) == NULL)
		hostname = "unknown";

	if (argc > 1)
	{
		if ((*++argv)[0] == '-')
		{
			for (s = argv[0]+1; *s != '\0'; s++)
			{
				switch(*s)
				{
					case 'r':
						r = 1;
						break;
					case 'f':
						f = 1;
						break;
					case 'h':
						h = 1;
						break;
					case 'k':
						k = 1;
						break;
					case 'c':
						c = 1;
						break;
					case 't':
						t = atoi(argv[1]);
						break;
					default:
						printf ("%s: invalid option %c\n", shutn, *s);
						(void) dohelp();
						return 1;	
						break;
				}

			}

		}

	}

	if (t < 0)
		t = 1;

	if (k)
	{
		(void) dowall(0, r);
		return 1;
	}

	if (!c)
	{
		if (r)
			printf ("Shutting down for reboot...");
		else
			printf ("The system is being halted now...");

		(void) fflush(stdout);
		(void) dowall(0, r);

		creat(_PATH_NOLOGIN, 644);

		if (f)
			creat(_PATH_FASTBOOT, 644);

		t+=2;
		sleep(t);	/* Delay minimum 2 seconds */

		if (t > 5)
		{
			t = 0;
			(void) dowall(3, r);
		}

		logwtmp("console", "shutdown", hostname);

		sync();

		sleep(2);	/* Delay 2 seconds */

		if (!h)
			Shutdown(r);
		else
			if (!kill(1, SIGTERM))
				kill(1, SIGKILL);
		/* SIGKILL can't fail */
		return 1;
	}
	else
	{
		(void) remove(_PATH_NOLOGIN);
		(void) remove(_PATH_FASTBOOT);
		printf("Shutdown cancelled.\n");
		(void) kill(0,SIGTERM);
	/* Not reached? */
	}
	return 1;

}
