/*
 *	uptime.c - (C) 03/94 by Torsten Scherer (TeSche)
 *      slightly modified by Benjamin Lorenz in 6/94
 */

#include <time.h>
#include <utmp.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <mintbind.h>
#include <stdlib.h>
#include <fcntl.h>

#define	ulong	unsigned long

void report(long s)
{
	long		ret;
	ulong		uptime;
	ulong		load[3];
	time_t		t;
	struct tm	*tp;
	short		loc_hours, updays, uphours, users;
	char		user[6];
	char		loc_flag = 'a';
	struct utmp	utmp;
	short		utmph;

	do {
		t = time(0);
		if (!(tp = localtime(&t))) {
			fprintf(stderr, "error: can't convert time to localtime\n");
			exit(-1);
		}
		if ((loc_hours = tp->tm_hour) > 12) {
			loc_hours -= 12;
			loc_flag = 'p';
		}

		if ((utmph = open("/etc/utmp", O_RDONLY, 0)) < 0) {
			fprintf(stderr, "error: can't open /etc/utmp\n");
			exit(-1);
		}
		users = 0;
		while (read(utmph, &utmp, sizeof(struct utmp)) == sizeof(struct utmp)) {
			if (*utmp.ut_name)
				users++;
		}
		close(utmph);

		if (users<2)
			strcpy(user, "user");
		else
			strcpy(user, "users");

		if ((ret = Suptime(&uptime, &load))) {
			fprintf(stderr, "error: uptime() returned %li\n", ret);
			exit(-1);
		}
		uptime /= 60;
		updays = uptime / 1440;
		uptime -= updays * 1440;
		uphours = uptime / 60;
		uptime -= uphours * 60;
         if (!updays) 
           if (!uphours) 
              printf("  %i:%02i%cm  up %i min,  %i %s,  load average: %.2f, %.2f, %.2f\n",
		       loc_hours,
		       tp->tm_min,
		       loc_flag,
		       uptime,
		       users,
		       user,
		       (float)load[0]/2048,
		       (float)load[1]/2048,
		       (float)load[2]/2048);
	      else
		printf("  %i:%02i%cm  up %i:%02li,  %i %s,  load average: %.2f, %.2f, %.2f\n",
		       loc_hours,
		       tp->tm_min,
		       loc_flag,
		       uphours,
		       uptime,
		       users,
		       user,
		       (float)load[0]/2048,
		       (float)load[1]/2048,
		       (float)load[2]/2048);
            else if (updays==1) 
		printf("  %i:%02i%cm  up %i day, %i:%02li,  %i %s,  load average: %.2f, %.2f, %.2f\n",
		       loc_hours,
		       tp->tm_min,
		       loc_flag,
		       updays,
		       uphours,
		       uptime,
		       users,
		       user,
		       (float)load[0]/2048,
		       (float)load[1]/2048,
		       (float)load[2]/2048);
	      else
		printf("  %i:%02i%cm  up %i days, %i:%02li,  %i %s,  load average: %.2f, %.2f, %.2f\n",
		       loc_hours,
		       tp->tm_min,
		       loc_flag,
		       updays,
		       uphours,
		       uptime,
		       users,
		       user,
		       (float)load[0]/2048,
		       (float)load[1]/2048,
		       (float)load[2]/2048);
		if (s)
			sleep(s);

	} while (s);
}

void main(long argc, char *argv[])
{
	long	s = 0;

	if (argc == 2)
		s = atol(argv[1]);

	report(s);
}
