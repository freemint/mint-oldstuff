/* click.c - switch keyclick on or off (under MiNT)
 *
 * Written by knarf@nasim.cube.net (Frank Bartels)
 * on 15 Feb 1995. It's my first useful C-Program
 * and I hope you like it as my girlfriend does. ;)
 *
 */


#include <osbind.h>
#include <stdio.h>
#include <sysvars.h>

int usage(char * progname) {
	fprintf(stderr,"Usage: %s -y|-n to switch key click on or off.\n",progname);
	return 1;
}

int main(int argc, char *argv[]){

	long stack;

	if ( argc != 2) {
		return usage(argv[0]);
	}

	if ( argv[1][0]=='-' ) {
		switch(argv[1][1]) {
			case 'n': /* switch keyclick off */
				stack=Super(0L);
				conterm=conterm & ~1;
				Super(stack);
				return 0;
				break;
			case 'y': /* switch keyclick on */
				stack=Super(0L);
				conterm=conterm | 1;
				Super(stack);
				return 0;
				break;
			default:
				return usage(argv[0]);
				break;

		}
	} else return usage(argv[0]);
}
