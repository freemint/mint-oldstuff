#define LEN 1024*10
int main(int argc, char **argv)
{
	char buffer[LEN];
	int len;
	do {
		len=read(0, buffer, LEN);
		write(1, buffer, len);
		write(2, ".", 1);
	} while (len);
}
