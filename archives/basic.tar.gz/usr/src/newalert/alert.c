#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __TURBOC__
#include <tos.h>
#include <aes.h>
#endif

#ifdef __MINT__
#include <osbind.h>
#include <mintbind.h>
#include <aesbind.h>
extern short _app;
extern short _global[];
#endif

#define FALSE 0
#define TRUE (!FALSE)


int gl_apid;
int __mint;
int rtx_found;


typedef struct {
	long id;
	long value;
} COOKIE;


#define cookie_init() \
	COOKIE *p; \
	long ssp = -1; \
	\
	if (Super((void *)1) == 0) \
		ssp = Super((void *)0); \
	p = *((COOKIE **)0x5a0l)

#define cookie_end() \
	if (ssp != -1) \
		(void)Super((void *)ssp)


int CK_JarInstalled(void)
{
	int installed;
	
	cookie_init();
	installed = p != NULL ? TRUE : FALSE;
	cookie_end();
	return(installed);
}



static COOKIE *SearchJar(char *id)
{
	cookie_init();
	while (p != NULL)
	{
		if (p->id == 0)
			p = NULL;
		else if (p->id == *(long *)id)
			break;
		else
			p++;
	}
	cookie_end();
	return(p);
}


int CK_ReadJar(char *id, long *value)
{
	COOKIE *p;
	
	p = SearchJar(id);
	if (p != NULL)
	{
		if (value != NULL)
			*value = p->value;
		return(TRUE);
	}
	return(FALSE);
}


void gem_exit(void)
{
	appl_exit();
}


int gem_init(void)
{
	long mint_vers;
	
    gl_apid = appl_init();
	
	if (CK_ReadJar("MiNT", &mint_vers) != FALSE)
	{
		__mint = (int)mint_vers;
	}
#ifdef __TURBOC__
	if (_GemParBlk.global[1] != 1)
#else /* __MINT__ */
	if (_global[1] != 1)
#endif
		rtx_found = TRUE;
	return(gl_apid);
}


#undef O_RDWR
#undef O_CREAT
#undef O_TRUNC
#undef O_NDELAY
#define O_RDWR		0x002
#define O_DENYNONE  0x040	/* don't deny any access to others */
#define O_CREAT		0x200	/* create file if it doesn't exist */
#define O_TRUNC		0x400	/* truncate file to 0 bytes if it does exist */
#define O_NDELAY	0x100	/* don't block for i/o on this file */

#define F_GETFD		1		/* handled by kernel */
#define F_SETFD		2		/* handled by kernel */
#define F_GETFL		3		/* handled by kernel */
#define F_SETFL		4		/* handled by kernel */


#define MAX_STR_LEN 1024


#if 0
void ensure_alert(char *s)
{
	char alertbuf[MAX_STR_LEN+1];
	char *ptr;
	char *lastspace;
	int counter;
	
	/* already an alert ? */
	if (*s != '[')
	{
		strcpy(alertbuf, "[1][");
		strncpy(alertbuf+4, s, MAX_STR_LEN-4-7);
		alertbuf[MAX_STR_LEN] = '\0';
/*
 * make sure no lines exceed 30 characters; also, filter out any
 * reserved characters like '[' or ']'
 */
		ptr = alertbuf+4;
		counter = 0;
		lastspace = 0;
		while (*ptr)
		{
			if (*ptr == ' ')
			{
				lastspace = ptr;
			} else if (*ptr == '[')
			{
				*ptr = '(';
			} else if (*ptr == ']')
			{
				*ptr = ')';
			} else if (*ptr == '|')
			{
				*ptr = ':';
			}
			if (counter++ >= 29)
			{
				if (lastspace)
				{
					*lastspace = '|';
					counter = (int) (ptr - lastspace);
					lastspace = 0;
				} else {
					*ptr = '|';
					counter = 0;
				}
			}
			ptr++;
		}
		strcpy(ptr, "][  OK  ]");
		strcpy(s, alertbuf);
	}
}
#endif


int main()
{
	const char *why_not = NULL;
	long pipe_fd = -1;
	char alert_buf[MAX_STR_LEN+1];
	
	gem_init();
	if (_app && !rtx_found)
	{
		form_alert(1, "[1][Can only run as ACC][Abort]");
		gem_exit();
		return(1);
	}
	
	{
		int apid;
		
		if ((apid = appl_find("ALERT   ")) >= 0 && apid != gl_apid)
		{
			/* Application already running */
			int message[8];
			message[0] = AC_OPEN;
			message[1] = gl_apid;
			message[2] = message[3] = message[4] = message[5] = message[6] = message[7] = 0;
			appl_write(apid, 16, message);
			gem_exit();
			return(0);
		}
	}
	
	menu_register(gl_apid, "  Alerts");
	
	if (__mint == 0)
		/* MiNT is not running - you loose */
		why_not = "[1][MiNT not running][Exit]";
	else if ((pipe_fd = Fopen("U:\\PIPE\\ALERT", O_RDWR|O_CREAT|O_TRUNC|O_NDELAY|O_DENYNONE)) < 0)
		why_not = "[1][Couldn't create Alert pipe][Exit]";
	else if (pipe_fd >= 32)
	{
		Fclose((int)pipe_fd);
		why_not = "[1][File descriptor out of range][Exit]";
	}
	
	if (why_not != NULL)
	{
		if (_app)
		{
			form_alert(1, why_not);
		} else {
			int message[8];
			
			for (;;)
			{
				evnt_mesag(message);
				if (message[0] == AC_OPEN)
					form_alert(1, why_not);
			}
		}
	} else {
		int message[8];
		int dummy;
		int event;

		/*
		 * since we are running as an Accessory, the owner of the
		 * file is GEM, so we must clear the close-on-exec flag,
		 * or GEM will raise an BUS-Error when executing programs
		 */
		Fcntl((int)pipe_fd, 0l, F_SETFD);
		
		alert_buf[0] = '\0';
		for (;;)
		{
			event = evnt_multi(MU_MESAG|MU_TIMER,
				0, 0, 0,
				0, 0, 0, 0, 0,
				0, 0, 0, 0, 0,
				message,
#if defined(__TURBOC__) || defined(__TCC_GEMLIB__)
				500, 0,
#else
              500l,
#endif
				&dummy, &dummy, &dummy, &dummy, &dummy, &dummy);
			if (event & MU_TIMER)
			{
				long count;
				
				if ((count = Fread((int)pipe_fd, (long)sizeof(alert_buf), alert_buf)) > 1)	
				{
					if (alert_buf[0] == '[' &&
						alert_buf[count-2] == ']' &&
						alert_buf[count-1] == 0)
					{
						graf_mouse(ARROW, NULL);
						form_alert(1, alert_buf);
					} else
						alert_buf[0] = 0;
				}
			}
			if (event & MU_MESAG)
			{
				if (message[0] == AC_OPEN)
				{
					if (alert_buf[0] == '\0')
						form_alert(1, "[1][No alerts yet][OK]");
					else
						form_alert(1, alert_buf);
				}
			}
		}
	}
	gem_exit();
	return(0);
}
