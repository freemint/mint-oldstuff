int main(void)
{
	(*((void (*)(void))(((char *)main) + 1)))();
	return(0);
}
