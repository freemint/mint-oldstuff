#include <tos.h>
int main()
{
	char *adr;
	
	adr = Malloc(8192);
	adr[8192] = adr[8192];
	*((char *)0) = 0;
	return(0);
}
