/* file:  reboot.c
 *        shut down the system
 *
 * If REBOOT is defined, restart the system after shutdown, otherwise
 * just halt the system so that it can be switched off securely.
 *
 * Ulrich Kuehn, 02-Nov-94
 */

#include <mintbind.h>
#include <stdio.h>


#ifndef Shutdown
#ifdef __GNUC__  /* temorary hack for gnu c */
#define Shutdown(a)  (long) trap_1_wl((short)0x151, (long)(a))
#endif
#endif


int
main()
{
#ifdef REBOOT
	long v = 1;
#else
	long v = 0;
#endif

	if (!Shutdown(v))
		printf("Cannot shut down the system.\n");
	return 1;
}
