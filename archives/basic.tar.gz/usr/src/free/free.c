#include <stdio.h>
#include <osbind.h>

main()
{
        printf("Largest free block: %lu bytes\n", Malloc(-1l));
        exit(0);
}
