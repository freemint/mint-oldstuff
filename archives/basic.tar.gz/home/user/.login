# ~/.login wird bei jedem Login gelesen
