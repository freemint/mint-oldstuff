# ~/.cshrc wird von jeder tcsh gelesen.
# Existiert jedoch ~/.tcshrc wird diese stattdessen gelesen.
