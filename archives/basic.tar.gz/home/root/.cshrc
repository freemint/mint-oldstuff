# ~root/.cshrc: Diese Datei wird von jeder tcsh gelesen und
# zwar nach /etc/csh.cshrc.
#
# Der PATH fuer root wird etwas erweitert.
set path = ( /usr/etc ${path} )

# Das (-A) sollte eigentlich der ls von alleine bei root machen.
alias	ls	'ls -AF'
