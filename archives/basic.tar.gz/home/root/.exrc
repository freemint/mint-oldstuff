set nocrlf showmode
