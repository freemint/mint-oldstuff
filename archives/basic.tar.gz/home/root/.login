# ~root/.login
#
# Diese Datei wird von jeder tcsh gelesen, die als Login-Shell gestartet
# wurde.
