# /etc/csh.cshrc - Wird von jeder tcsh gelesen
#
# echo Lese /etc/csh.cshrc
#
umask 022
#
if ( -d /usr/bin/X11 ) then
	set path=( /usr/local/bin /usr/ucb /bin /usr/bin/X11 )
else
	set path=( /usr/local/bin /bin /usr/ucb )
endif
#
if ( $?prompt ) then
	#
	# Einen unauffindbaren Bug beheben. Wo? Keine Ahnung...
	#
	stty quit ^\\
endif

set prompt = '%B%M:%/%#%b '

set history=100
set savehist=100
set histsave

set notify

set autolist = ambiguous
set matchbeep = nomatch

# Die Virtuellen Consolen koennen jetzt ISO-8859-1, damit less das auch weiss:
setenv LESSCHARSET latin1
# Und damit das ganze noch ein wenig besser funktioniert...
setenv LC_CTYPE iso_8859_1

# Die Variable GCCEXEC darf nicht gesetzt werden!
setenv GNULIB /usr/lib
setenv GNUINC /usr/include

setenv TMP /tmp
setenv TEMP /tmp
setenv TMPDIR /tmp

# So will es die MiNT-Library haben. Hoffentlich wird der Timezone-Support
# mal etwas besser. Die Uhr muss dazu localtime laufen...

setenv TZ MET-1METDST

#
# Das leidige UNIXMODE. Doku dazu in /usr/doc/UNIXMODE.doc
#
setenv UNIXMODE "/brUs"

setenv SHELL /bin/sh

#
# aliases:
#

alias	ll	'ls -lF'

# Wer's mag...
# alias	pwd	'echo $cwd'

alias	j	'jobs -l'

alias	po	'popd'
alias	pu	'pushd'

alias	zx	'tar xzvf'
alias	zt	'tar tzvf'

# Ein paar sinnvolle key-Bindings fuer VT52 (wuerg)

bindkey ^[E history-search-backward
bindkey ^[a history-search-forward
