#
# /etc/rc.boot -- Executed by init(8) at boot time before
#                 /etc/rc. Network setup goes in /etc/rc.net,
#                 local customisation goes in /etc/rc.local
#
umask 022
HOME=/; export HOME
PATH=/bin:/usr/etc:/usr/bin:/usr/lib; export PATH

#
# Check filesystems on normal boot or after systemcrash.
#
if [ -f /etc/fastboot ]; then
	echo "Fast boot. Skipping filesystem checks."
	rm -f /etc/fastboot
else
	mfsdrives=`grep -v '^#' /etc/fstab | \
	while read drv mntp type owner group perm; do
		if [ "X$type" = Xminix ]; then
			echo "$drv"
		fi
	done`
	for drv in $mfsdrives; do
		echo; echo "Checking filesystem on drive $drv."
		fsck -p $drv:
		if [ $? -ne 0 ]; then
			echo
			echo "Warning: fsck FAILED"
			echo "         Starting single user shell. Fix the"
			echo "         filesystem on drive $drv and REBOOT!"
			echo
			sh -si < /dev/console > /dev/console 2>&1
		fi
	done
fi

#
# Mount filesystems and set owner/permissions from /etc/fstab.
#
cat /dev/null > /etc/mtab
grep -v '^#' /etc/fstab | \
while read drv mntp type owner group perm; do
	if [ -d "/$drv" ]; then
		fs="/$drv"
	elif [ -d "/.$drv" ]; then
		fs="/.$drv"
	else
		echo "Warning: drive $drv not found"
		drv="-"; fs="-"
	fi
	if [ "X$fs" != "X-" -a "X$owner" != "X-" ]; then
		chown "$owner" "$fs"
	fi
	if [ "X$fs" != "X-" -a "X$group" != "X-" ]; then
		chgrp "$group" "$fs"
	fi
	if [ "X$fs" != "X-" -a "X$perm" != "X-" ]; then
		chmod "$perm" "$fs"
	fi
	if [ "X$drv" != "X-" -a "X$mntp" != "X-" -a "X$type" != "X-" ]; then
		echo "$drv	$mntp" >> /etc/mtab
		if [ "X$mntp" != "X/" ]; then
			mount -t "$type" "$drv:" "$mntp"
		fi
	fi
done

exit 0

