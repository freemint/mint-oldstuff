# /etc/csh.login - Wird nur beim Login gelesen
#
# echo Lese /etc/csh.login
#
# Files you make look like rw-r--r--
#
umask 022

set defterm="vt100"

if (! ${?term}) set term=dumb

if ($term == "dumb" || $term == "network" || $term == "unknown" || $term == "dialup") then
   if ($tty != "console") then
      echo -n "TERM = ("$defterm") "
      set term=$<
      if ( $term =~ "" ) set term=$defterm
      setenv TERM $term
   else
      set term=st52
   endif
else
   echo term=$term
endif
#
# Zeigt den freien Speicher an.
#
/bin/free
#
# Ordentlichen Font laden
#
switch ($tty)
	case console:
		ttyvfont iso-atari-16.fnt && echo ISO-8859-1 Font geladen.
		breaksw
	case ttyv?:
		ttyvfont iso-atari-16.fnt && echo ISO-8859-1 Font geladen.
		breaksw
endsw
